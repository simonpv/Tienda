package com.tienda;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
/*
@SpringBootTest
class TiendaApplicationTests {

        @Disabled
	@Test
	void contextLoads() {
	}

}
*/